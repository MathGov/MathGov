# MathGov Interior Metadata 1.0.0 — review before installation

**Not installed or activated by this website pass.** This helper addresses missing description tags on selected interior pages. It is not needed for the already-described homepages, AIAP or Journey pages.

Upload the ZIP in WordPress Plugins > Add New > Upload Plugin and activate it separately on each approved site. Review the PHP first. Then purge LiteSpeed cache and inspect the actual page head. Deactivate the helper if another SEO plugin begins emitting descriptions; the common plugin checks are a courtesy, not a universal conflict detector.

The code only emits one escaped description through WordPress `wp_head`, for explicitly mapped public pages on ripplelogic.org or mathgov.org. It does not alter titles, page text, downloads, licenses, robots directives or canonical links; does not create tables or update options; makes no external requests; performs no tracking. It does not generate redirects. Deactivation stops the output; clear cached pages afterward.

Verification: PHP syntax and isolated stub tests are supplied in the closeout package. These are not a live WordPress installation test or third-party security audit.

Reference documentation:
- https://developer.wordpress.org/reference/hooks/wp_head/
- https://developer.wordpress.org/reference/functions/esc_attr/
- https://developer.wordpress.org/plugins/plugin-basics/header-requirements/

GPL-2.0-or-later applies to this new helper code only. It does not change any publication's license.

<?php
/**
 * Plugin Name: MathGov Interior Metadata
 * Description: Adds reviewed descriptions to selected public MathGov and RippleLogic pages. No external calls, tracking or database writes.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: MathGov
 * License: GPL-2.0-or-later
 * Update URI: false
 */
if (!defined('ABSPATH')) {
    exit;
}

/** Emit only a description for a reviewed public page, without touching its content. */
function mathgov_interior_description_20261012() {
    if (is_admin() || is_feed() || is_preview() || !is_singular('page') || is_front_page()) {
        return;
    }
    // Yield to a full SEO plugin rather than deliberately producing duplicate descriptions.
    if (defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION') || defined('AIOSEO_VERSION') || defined('SEOPRESS_VERSION') || function_exists('the_seo_framework')) {
        return;
    }
    $post = get_queried_object();
    if (!($post instanceof WP_Post) || get_post_status($post) !== 'publish' || post_password_required($post)) {
        return;
    }
    $host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
    $host = preg_replace('/^www\./', '', $host);
    $common = array(
        'about-james-mathgov' => 'Meet James MathGov, educator and research steward of MathGov and RippleLogic. Explore documented origins, current sources and contact information.',
        'mathgov-origins' => 'Explore MathGov\'s documented origins, the original university thesis record and a separately proposed contemporary reassessment.',
        'published-commentary' => 'Read about James MathGov\'s published commentary, with attribution and links to the original GFiles India articles.',
        'universal-intelligence-alignment-constitution' => 'Explore the proposed Universal Intelligence Alignment Constitution, its review purpose and limits. The proposal is unadopted, not a law or certification.',
    );
    $by_host = array(
        'ripplelogic.org' => array_merge($common, array(
            'start-here' => 'Start learning RippleLogic: ground evidence, protect rights, examine severe risk, test viability and compare only qualifying choices.',
            'core-logic' => 'Understand the RippleLogic decision cascade: Reality Grounding, Rights Floor, Tail-Risk Constraint, Structural Viability and survivor-only ranking.',
            'library' => 'Find RippleLogic\'s current public sources, release records and learning routes. Historical editions and research boundaries remain explicit.',
            'research-publications' => 'Explore MathGov and RippleLogic research, books and commentary, with clear distinctions between published sources and review candidates.',
            'run' => 'Find current RippleLogic learning routes and the fixed teaching example. This guide is not a live decision engine or certification service.',
            'scenarios' => 'Explore public RippleLogic learning examples while keeping illustration, case evidence and validation claims separate.',
            'watch' => 'Find RippleLogic\'s published visual learning materials, illustrated book and source library, with accurate edition and evidence boundaries.',
            'guardrails' => 'Explore RippleLogic rights, risk and viability requirements through current public sources. Specifications do not confer enforcement or authority.',
        )),
        'mathgov.org' => array_merge($common, array(
            'publications' => 'Browse MathGov research and publications, separating current public sources, historical scholarship and works awaiting review or release.',
            'books-education' => 'Explore MathGov and RippleLogic books, public introductions and educational materials, with clear labels for available and proposed editions.',
        )),
    );
    if (!isset($by_host[$host][$post->post_name])) {
        return;
    }
    $description = $by_host[$host][$post->post_name];
    echo "\n<!-- MathGov Interior Metadata 1.0.0 -->\n";
    echo '<meta name="description" content="' . esc_attr($description) . '">' . "\n";
}
add_action('wp_head', 'mathgov_interior_description_20261012', 6);
